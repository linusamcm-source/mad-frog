#!/bin/bash
#
# git commit -m <message>
# If no message is provided, auto-generate one using Claude.
#

msg="$1"

if [ -z "$msg" ]; then
    if [ -z "$(git diff --cached --name-only)" ]; then
        echo "No staged changes to commit."
        exit 0
    fi

    echo "Generating commit message..."
    msg=$(git diff --cached | claude -p --model haiku "Write a concise, conventional git commit message for these changes. Output ONLY the raw message text. Do not use markdown code blocks or quotes.")
fi

if [ -z "$msg" ]; then
    echo "Aborting: No commit message provided or generated."
    exit 1
fi

echo "Commit message: $msg"

git commit -m "$msg"
