#!/bin/bash
#
# Author: Diogo Alexsander Cavilha <diogocavilha@gmail.com>
# Date:   04.21.2018
#
# git add --all
# git commit -m <message>
# git push origin <current_branch_name>

branch_name=$(git branch | grep -oP '(?<=\* ).*')
msg="$1"

git add --all

if [ -z "$(git diff --cached --name-only)" ]; then
    echo "No changes to commit."
    exit 0
fi

if [ -z "$msg" ]; then
    echo "Generating commit message..."
    msg=$(git diff --cached | claude -p --model haiku "Write a concise, conventional git commit message for these changes. Output ONLY the raw message text. Do not use markdown code blocks or quotes.")
fi

if [ -z "$msg" ]; then
    echo "Aborting: No commit message provided or generated."
    exit 1
fi

echo "Commit message: $msg"

git commit -m "$msg" && \
git push origin "$branch_name"