#!/bin/bash
#
# Create a pull request with a Claude-generated title and description.
# Uses the full diff against the base branch to summarize all changes.
#

branch_name=$(git branch | grep -oP '(?<=\* ).*')
base_branch="$1"

if [ -z "$base_branch" ]; then
    echo "Usage: gpr <base-branch>"
    exit 1
fi

if [ "$branch_name" = "$base_branch" ]; then
    echo "You're already on $base_branch. Switch to a feature branch first."
    exit 1
fi

# Ensure branch is pushed to remote
if ! git ls-remote --exit-code --heads origin "$branch_name" > /dev/null 2>&1; then
    echo "Pushing branch to origin..."
    git push -u origin "$branch_name" || exit 1
fi

diff=$(git diff "$base_branch"..."$branch_name")
log=$(git log "$base_branch".."$branch_name" --oneline)

if [ -z "$diff" ]; then
    echo "No changes found between $branch_name and $base_branch."
    exit 0
fi

echo "Generating PR title..."
title=$(printf '%s\n\nCommits:\n%s' "$diff" "$log" | claude -p --model haiku "Write a clear, concise pull request title (under 70 chars) for these changes. Output ONLY the raw title text. No markdown, no quotes, no prefix.")

if [ -z "$title" ]; then
    echo "Aborting: Failed to generate PR title."
    exit 1
fi

echo "Generating PR description..."
body=$(printf '%s\n\nCommits:\n%s' "$diff" "$log" | claude -p --model haiku "Write a detailed pull request description for these changes. Use this format:

## Summary
A brief overview of what this PR does (2-3 sentences).

## Changes
- Bullet point each meaningful change

## Notes
Any important context, trade-offs, or things reviewers should know.

Output ONLY the raw markdown. No code fences wrapping the whole thing.")

if [ -z "$body" ]; then
    echo "Aborting: Failed to generate PR description."
    exit 1
fi

echo ""
echo "Title: $title"
echo ""
echo "$body"
echo ""

gh pr create --title "$title" --body "$body" --base "$base_branch"
